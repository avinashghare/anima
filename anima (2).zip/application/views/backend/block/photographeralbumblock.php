<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editphotographeralbum?id=').$before->id; ?>">Photographer Album Details</a></li>
<li><a href="<?php echo site_url('site/viewalbumimage?id=').$before->id; ?>">Photographer Album Images</a></li>
<li><a href="<?php echo site_url('site/viewphotographervideo?id=').$before->id; ?>">Photographer Videos</a></li>
</ul>
</div>
</section>