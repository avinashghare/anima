<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.themeregion.com/doors -fade-slider/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 03 Nov 2014 12:18:21 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<!--title-->
    <title>Anima Creative Management</title>
	
	<!--CSS-->
<!--
	<link href="css/style.css" rel="stylesheet">	
	<link href="css/insta.css" rel="stylesheet">	
	<link href="css/dl-menu.css" rel="stylesheet">	

    <script src="js/modernizr.custom.js"></script>
-->

    <link href="<?php echo base_url('frontassets/css/style.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('frontassets/css/insta.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('frontassets/css/dl-menu.css'); ?>" rel="stylesheet">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="<?php echo base_url('frontassets/js/modernizr.custom.js'); ?>"></script>
    <script src="<?php echo base_url('frontassets/js/jquery.dlmenu.js'); ?>"></script>
    
	<script type="text/javascript">

     $(document).ready(function () {
         $('.model_single img, .model_name').delay(1000).fadeIn('slow');

     });
    </script>

    <style>
        .model_single img, .model_name{display: none;}
</style>
</head><!--/head-->
<body>
	<!-- Page Loader -->
	<!--<div class="preloader">
        <div id="loaderImage"></div>
    </div>-->
    <div class="wrapper">
     <?php
$this->load->view("frontend/header");
?>
  
        <!--<header class="mobile_menu"> 
            <a href="index.php"><div class="mobile_logo"></div></a>
            <div id="dl-menu" class="dl-menuwrapper">
						<button class="dl-trigger"></button>
						<ul class="dl-menu">
							<li>
								<a href="#">Model</a>
								<ul class="dl-submenu">
							        <li><a href="females_in_town.php">Female In Town</a></li>
							        <li><a href="#">Female Out of Town</a></li>
							        <li><a href="#">Male In Town</a></li>
							        <li><a href="#">Male Out of Town</a></li>
					        	</ul>
					    </li>
					    <li><a href="#">Creative Artists</a></li>
                        <li><a href="#">Agency</a></li>
                        <li><a href="#">News</a></li>
						</ul>
					</div>
        </header>--> 


        <div class="container">
            <div class="page_title">Become A Model</div>
                <div class="become_model">
                    <p>Girls aged between 16-22 years old, with a minimum of 172cm/5'7.5
                    <p>If you think you have what it takes to become an Anima Model</p>
                    <p>Send in your latest polaroid to : newfaces@animacreatives.com</p>
                    <p>Please make sure the pictures are clear and show off your body and face.</p>
                    <p>We need 4 images... full length, both profiles and front on shots.</p>
                    <p>Include the below information in your application</p>
                    <p>age<br />height<br />bust<br />waist<br />hips<br />contact number<br /></p>
                    <p>if you have portfolio pictures, do send them in also, but you must include the below polaroid, 'wearing no make up'.
                    <p>** Do not contact the agency regarding your application, the agency will contact you should you be successful.<br />
                    *** Please do not send hi res files over 600kb of size per image</p>                
                
                <div class="col-4"><img src="<?php echo base_url('frontassets/images/agency/img1.jpg'); ?>" alt="1"></div>
                <div class="col-4"><img src="<?php echo base_url('frontassets/images/agency/img2.jpg'); ?>" alt="1"></div>
                <div class="col-4"><img src="<?php echo base_url('frontassets/images/agency/img3.jpg'); ?>" alt="1"></div>
                <div class="col-4"><img src="<?php echo base_url('frontassets/images/agency/img4.jpg'); ?>" alt="1"></div>
                
                </div>
                
        
        <div id="footer">
                <hr class="footer_top" />
                <div class="footer_menu">
                <ol class="pxmenu">
                    <li>Contact Us</li>
                    <li>Terms & Conditions</li>
                    <li>Privacy Policy</li>
                    <li>Careers</li>
                    <li>FAQs</li>
                </ol>
                </div>
                <div class="copyright">© Copyright ANIMA CREATIVES 2014</div>
                <div class="hepta">MADE WITH LOVE BY HEPTA</div>
            </div>
    </div>
	
	

	<!--/#scripts--> 
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
		<script src="<?php echo base_url('frontassets/js/jquery.dlmenu.js'); ?>"></script>
		<script>
			$(function() {
				$( '#dl-menu' ).dlmenu();
			});
		</script>

	<!--/#scripts--> 
    <!--<script type="text/javascript" src="js/jquery.js"></script>-->
    <script type="text/javascript" src="<?php echo base_url('frontassets/js/custom.js'); ?>"></script>
<!--    <script type="text/javascript" src="js/custom.js"></script>-->
    <!--<script type="text/javascript" src="js/jquery.instastream.js"></script>-->
    
</body>

</html>