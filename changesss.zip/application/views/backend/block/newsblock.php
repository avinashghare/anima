<section class="panel">

    <div class="panel-body">
        <ul class="nav nav-stacked">
            <li><a href="<?php echo site_url('site/editnews?id=').$before->id; ?>">News Details</a></li>
            <li><a href="<?php echo site_url('site/viewnewsimage?id=').$before->id; ?>">News Images</a></li>
<!--            <li><a href="<?php echo site_url('site/viewuserinterestevents?id=').$before->id; ?>">User Interest Events</a></li>-->
        </ul>
    </div>
</section>