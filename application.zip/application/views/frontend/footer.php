            <div id="footer">
                    <hr class="footer_top" />
                    <div class="footer_menu">
                <!--<ol>
                    <li>Contact Us</li>
                    <li>Terms & Conditions</li>
                    <li>Privacy Policy</li>
                    <li>Careers</li>
                    <li>FAQs</li>
                </ol>-->
                </div>
                <div class="copyright">© Copyright ANIMA CREATIVES 2014</div>
                <div class="hepta">MADE WITH LOVE BY <strong><a href="http://hepta.me/" target="_blank">HEPTA</a></strong></div>
                </div>                  
            </div>