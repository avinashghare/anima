<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.themeregion.com/doors -fade-slider/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 03 Nov 2014 12:18:21 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<!--title-->
    <title>Anima Creative Management</title>
	
	<!--CSS-->
<!--
	<link href="frontassets/css/style.css" rel="stylesheet">	
	<link href="frontassets/css/insta.css" rel="stylesheet">	
	<link href="frontassets/css/dl-menu.css" rel="stylesheet">	
-->

    <link href="<?php echo base_url('frontassets/css/style.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('frontassets/css/insta.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('frontassets/css/dl-menu.css'); ?>" rel="stylesheet">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="<?php echo base_url('frontassets/js/modernizr.custom.js'); ?>"></script>
    <script src="<?php echo base_url('frontassets/js/jquery.dlmenu.js'); ?>"></script>
    
<!--
    <script src="js/modernizr.custom.js"></script>
    <script src="js/jquery.dlmenu.js"></script>
-->
<!--    <script src="frontassets/js/modernizr.custom.js"></script>-->
	
</head><!--/head-->
<body>
	<!-- Page Loader -->
	<!--<div class="preloader">
        <div id="loaderImage"></div>
    </div>-->
    <div class="wrapper">